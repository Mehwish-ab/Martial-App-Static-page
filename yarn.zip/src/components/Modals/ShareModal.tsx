const ShareModal = () => {
    return <div>ShareModal</div>
}

export default ShareModal
