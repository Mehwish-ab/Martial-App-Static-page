import React from 'react'

const ProfileBox = () => {
    return <div>ProfileBox</div>
}

export default ProfileBox
