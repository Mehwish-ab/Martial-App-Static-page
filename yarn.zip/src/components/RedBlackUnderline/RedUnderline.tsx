import { UnderlineRed } from '../GlobalStyle'

const RedUnderline = () => {
    return (
        <div className="d-flex justify-content-center">
            <UnderlineRed />
        </div>
    )
}

export default RedUnderline
