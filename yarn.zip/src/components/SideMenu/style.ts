import styled from 'styled-components'

export const SideMenuStyle = styled.div``
