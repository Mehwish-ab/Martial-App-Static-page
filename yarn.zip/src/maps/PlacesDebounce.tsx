import React from 'react'

const PlacesDebounce = () => {
    return <div>PlacesDebounce</div>
}

export default PlacesDebounce
