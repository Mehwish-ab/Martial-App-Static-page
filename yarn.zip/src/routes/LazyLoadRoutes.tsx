// import lazyLoad from "./LazyLoad";

// const Home = lazyLoad("./Screens/Home/Index");
// const FindHome = lazyLoad("./Screens/FindHome/Index");
// const PropertyDetails = lazyLoad("./Screens/PropertyDetails/Index");
// const FindProfessionals = lazyLoad("./Screens/FindProfessionals/Index");
// const ParentComponent = lazyLoad("./Screens/ParentComponent/Index");
// const Resources = lazyLoad("./Screens/Resources/Index");
// const Error = lazyLoad("./Components/404Page/404Page");

// const CreateProperty = lazyLoad(
//   "./Screens/CreateProperty/CreateProperty/Index"
// );
// const CreateProperty1 = lazyLoad(
//   "./Screens/CreateProperty/CreateProperty1/Index"
// );
// const CreateProperty2 = lazyLoad(
//   "./Screens/CreateProperty/CreateProperty2/Index"
// );

// const PaymentInfo = lazyLoad("./Screens/BillSummary/Index");
// const PropertyInfo = lazyLoad("./Screens/PropertyInfo/Index");
// const EditPhone = lazyLoad("./Screens/CreateProfessional/EditPhone");

// const BecomeProfessional = lazyLoad("./Screens/BecomeProfessional/Index");

// const CreatePost = lazyLoad("./Screens/CreatePost/CreatePost");
// const CreatePost1 = lazyLoad("./Screens/CreatePost/CreatePost1");
// const CreatePost2 = lazyLoad("./Screens/CreatePost/CreatePost2");
// const CreatePost3 = lazyLoad("./Screens/CreatePost/CreatePost3");
// const CreatePost4 = lazyLoad("./Screens/CreatePost/CreatePost4");

// const PostList = lazyLoad("./Screens/CreatePost/Index");

// const Confirmed = lazyLoad("./Components/Confirmed/Index");

// const ProfessionalProfile = lazyLoad("./Screens/ProfessionalProfile/Index");
// const PropertyParent = lazyLoad("./Screens/ParentComponent/PropertyParent");
// const Login = lazyLoad("./Components/Login/Index");
// const RegisterPhone = lazyLoad("./Components/RegisterPhone/Index");
// const VerifyOtp = lazyLoad("./Screens/VerifyOtp/Index");
// const Register = lazyLoad("./Components/Register/Index");
// const UserProfile = lazyLoad("./Screens/UserProfile/Index");
// const Homepage = lazyLoad("./Screens/Homepage/Index");
// const ExploreNearby = lazyLoad("./Screens/ExploreNearby/Index");
// const Story = lazyLoad("./Screens/Story/Index");
// import lazyLoad from "./LazyLoad";

export const LazyLoadRoutes = {}
