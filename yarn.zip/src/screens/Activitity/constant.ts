export type ActivityInitialValues = {
    selectBelt: number
    latestCertification: any
    startDate: Date
    endDate: Date
    experience: number
    selectedActivities: string
    activityId: string
}
